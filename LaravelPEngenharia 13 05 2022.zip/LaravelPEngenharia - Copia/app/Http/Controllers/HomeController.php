<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    //
    public function index(){
        
        //echo "Controller recebe dados aqui";
        $usuario= "Breno";
        $perfil = "Gerente";
        $empresa = "Google";
        $dados =[
            'usuario' =>$usuario,
            'perfil' => $perfil,
            'empresa'=> $empresa
        ];        

        return view ('welcome', $dados);

      }


    }


