<?php

namespace App\Http\Controllers;

class HomeController extends BaseController{

    public function lista(){


       return '<h1> Administração !!! </h1>';
       // <b>Seja Bem Vindo</b>';
    }
}

//action ([HomeController::class, 'admin']);

//return Redirect:: action([HomeController::class, 'admin']);



