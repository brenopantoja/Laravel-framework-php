<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProdutosControlller extends Controller
{
    //
    //public function index(){
    public function index(Request $request){
        
        //option 1
        $dados = $request -> all();//It has taking all data
        //print_r($dados);
      
      //  echo "produtos:".$dados['produto'];
      // echo "categoria: ".$dados['categoria'];
       /*
       //1º form of It does it:
       $produto = $dados['produto'];
       $preco = $dados ['preco'];
       $categoria = $dados['categoria'];
*/

// 2ª form of It does it:
/*
$produto = $request -> query('produtos');

$produto = $request -> query('preco');

$produto = $request -> query('categoria');
*/
//3ª form It does it:
    /*
    $produto = $request -> input('produto');
    $preco = $request -> input('preco');
    $categoria = $request -> input('categoria');
*/

//4ª form It does it
$dados= [
'produto' => $request -> input ('produto'),
'preco' => $request -> input ('preco'),
'categoria' => $request -> input ('categoria')


];

return view ('produtos', $dados);
//return view ('produtos', ['produto' => $produtos, 'preco' => $preco, 'categoria' =s> $categoria] );
//return view ('produto', ['produto'=> $produto, 'preco'=> $preco, 'categoria'=> $categoria] );

    }

    public function excluir ($id){
        echo $id;


    }
}
