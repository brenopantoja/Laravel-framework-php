        <h1>Lista de Produtos Disponíveis:</h1>   
        <hr>
       
      
        <form method="post">
            <!-- <form method="post"> -->
            
        <b>Produtos</b>
        <input type = "text" name="produto" ><br><br>
        
        <b> Preço </b>
        <input type="text" name ="preco"><br><br>

        <b> Categoria </b>
        <input type="text" name ="categoria"><br><br>

        <input type="submit" value ="Salvar">

        </form>
</hr>

<label> Produto: {{$produto}}</label><br>
<label> Preço: {{$preco}}</label><br>
<label> Produto: {{$categoria}}</label><br> 
    
