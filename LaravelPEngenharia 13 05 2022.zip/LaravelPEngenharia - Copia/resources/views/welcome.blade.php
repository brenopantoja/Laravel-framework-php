<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title> P. Engenharia </title>
        <h1>Seja bem Vindo</h1>        

        Meu nome é: {{$usuario}}
        Meu perfil é: {{$perfil}}
        Minha empresa é: {{$empresa}}
        
    </head>
    <body >
<div class ="wrapper">
    
    </body>
</html>
