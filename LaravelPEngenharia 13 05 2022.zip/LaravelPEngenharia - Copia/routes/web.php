<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProdutosControlller;

//Route::get('/', 'HomeController@index') ;
Route::get('/',[HomeController::class, 'index'] );

//Route::get('produtos',[ProdutosControlller::class, 'index'] );
Route::post('produtos',[ProdutosControlller::class, 'index'] );//It case wish has using post
Route::get('produtos/excluir/{id}', [ProdutosControlller::class, 'excluir']);
