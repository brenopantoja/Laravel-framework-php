<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;


//Route::get('/', 'HomeController@index') ;
Route::get('/', [HomeController::class, 'welcome'] ) ;

//    return view('welcome');


//});


/*

Route::get('/', function () {
    return view('welcome');
});

|-------------------------'-------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|


Route:: get ('/produtos', function(){
 return view ('produtos');
}

);

Route:: get ('/produtos/{nomeProduto}/comentario{id}', function($nomeProduto, $id){
// echo "Este é o comentário:".$id., "Páginas dos Produto:".$nomeProduto;
echo "Este é o comentário:".$id. "Páginas dos Produto".$nomeProduto; 
});

*/
//Route::get('/', 'welcome');


/*


 //It is work !
Route:: get('/', function(){
return 'Admininistração!';

});*/

//Route:: get('/admin', [HomeController:: class, 'admin']);
