<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title> P. Engenharia </title>
        <h1>Seja bem Vindo</h1>        

        Meu nome é: <?php echo e($usuario); ?>

        Meu perfil é: <?php echo e($perfil); ?>

        Minha empresa é: <?php echo e($empresa); ?>

        
    </head>
    <body >
<div class ="wrapper">
    
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\LaravelPEngenharia\resources\views/welcome.blade.php ENDPATH**/ ?>